/**
 *
 * Event doc: https://docs.aws.amazon.com/apigateway/latest/developerguide/set-up-lambda-proxy-integrations.html#api-gateway-simple-proxy-for-lambda-input-format
 * @param {Object} event - API Gateway Lambda Proxy Input Format
 *
 * Context doc: https://docs.aws.amazon.com/lambda/latest/dg/nodejs-prog-model-context.html
 * @param {Object} context
 *
 * Return doc: https://docs.aws.amazon.com/apigateway/latest/developerguide/set-up-lambda-proxy-integrations.html
 * @returns {Object} object - API Gateway Lambda Proxy Output Format
 *
 */
import mongoose from 'mongoose';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';

const secret_name = 'divinto-mongo-uri';

const client = new SecretsManagerClient({
  region: 'ap-northeast-1',
});

let response;

try {
  response = await client.send(
    new GetSecretValueCommand({
      SecretId: secret_name,
      VersionStage: 'AWSCURRENT', // VersionStage defaults to AWSCURRENT if unspecified
    }),
  );
} catch (error) {
  // For a list of exceptions thrown, see
  // https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
  throw error;
}

const secretObject = JSON.parse(response.SecretString);
console.log(secretObject);
const secret = secretObject.MONGODB_URI;
console.log(secret);
const cardContentBlockSchema = new mongoose.Schema({
  type: { type: String, enum: ['text', 'image', 'video', 'audio'] },
  content: String,
});
const CardSchema = new mongoose.Schema({
  id: String,
  title: String,
  position: {
    x: Number,
    y: Number,
  },
  content: {
    main: [cardContentBlockSchema],
    summary: String || null,
    approvement: String || null,
    disapprovement: String || null,
  },
  tags: [String],
  createdAt: {
    type: Date,
    default: () => Date.now(),
  },
  updateAt: {
    type: Date,
    default: () => Date.now(),
  },
  removeAt: {
    type: Date,
    default: null,
  },
});
const Card = mongoose.model('Card', CardSchema);

let cachedDb = null;

async function connectToDatabase(uri) {
  if (cachedDb && mongoose.connection.readyState === 1) {
    return cachedDb;
  }
  console.log(uri);

  cachedDb = await mongoose.connect(uri);
  return cachedDb;
}

export async function handler(event) {
  try {
    await connectToDatabase(secret);
    console.log('connect');
    const cards = await Card.find();
    if (!cards) return { statusCode: 404, body: 'No cards found' };
    console.log(cards[0]);

    const currentTime = new Date();
    let updateCards = [];

    cards.forEach((card) => {
      if (card.removeAt) return;
      const cardUpdateTime = new Date(card.updateAt);
      const oneDayAgo = new Date(currentTime.getTime() - 24 * 60 * 60 * 1000);
      if (cardUpdateTime > oneDayAgo) {
        updateCards.push(card._id.toString());
      }
    });
    console.log(updateCards);
    return {
      statusCode: 200,
      body: JSON.stringify(updateCards),
    };
  } catch (error) {
    console.error('Error during card check:', error);
    return { statusCode: 500, body: 'Internal Server Error' };
  }
}
